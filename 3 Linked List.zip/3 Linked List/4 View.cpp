#include <iostream>
using namespace std;

// 1. Deklarasi Struktur Data Node
struct Node {
    int nilai;
    Node* next;
};

typedef Node* Address;

struct List {
    Address First;
};

// 2. Fungsi Alokasi Memori (Membuat Node Baru)
Address alokasi(int nilaiInput) {
    Address P = new Node;
    P->nilai = nilaiInput;
    P->next = NULL;
    return P;
}

// Prosedur Pembantu Insert First (Untuk Mengisi Data Awal)
void insertFirst(List &L, Address P) {
    P->next = L.First;
    L.First = P;
}

// 3. Prosedur View / Print List (Operasi Penelusuran)
void viewList(List L) {
    Address P = L.First;

    // Cek apakah list kosong
    if (P == NULL) {
        cout << "List masih kosong!" << endl;
        return;
    }

    // Penelusuran dan menampilkan isi tiap node
    cout << "Isi Linked List: ";
    while (P != NULL) {
        cout << "[" << P->nilai << "] -> ";
        P = P->next; // Pindah ke node selanjutnya
    }
    cout << "NULL" << endl;
}

// 4. Program Utama (Driver)
int main() {
    List L;
    L.First = NULL; // Inisialisasi list kosong

    // Mengisi data sampel ke dalam list ([30] -> [20] -> [10] -> NULL)
    insertFirst(L, alokasi(10));
    insertFirst(L, alokasi(10));
    insertFirst(L, alokasi(20));
    insertFirst(L, alokasi(30));
    insertFirst(L, alokasi(10));

    cout << "=== OPERASI VIEW LINKED LIST ===" << endl;
    
    // Memanggil prosedur View
    viewList(L);

    return 0;
}
