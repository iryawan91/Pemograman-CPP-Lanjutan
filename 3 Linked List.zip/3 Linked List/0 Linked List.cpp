#include <iostream>
using namespace std;

// 1. Deklarasi Struktur Data Node
struct Node {
    int nilai;
    Node* next;
};

typedef Node* Address;

struct List {
    Address First;
};

// 2. Fungsi Alokasi Memori (Membuat Node Baru)
Address alokasi(int nilaiInput) {
    Address P = new Node;
    P->nilai = nilaiInput;
    P->next = NULL;
    return P;
}

// 3. Prosedur Insert First
void insertFirst(List &L, Address P) {
    P->next = L.First;
    L.First = P;
}

// 4. Prosedur Cetak Seluruh Nilai di List
void printList(List L) {
    Address P = L.First;
    if (P == NULL) {
        cout << "List masih kosong!" << endl;
        return;
    }

    cout << "Urutan Nilai dalam List (Dari Depan): ";
    while (P != NULL) {
        cout << "[" << P->nilai << "] -> ";
        P = P->next;
    }
    cout << "NULL" << endl;
}

// 5. Program Utama (Driver)
int main() {
    List L;
    L.First = NULL; // Inisialisasi list kosong

    int jumlahData, nilai;

    cout << "=== PROGRAM INPUT NILAI ===" << endl;
    cout << "Masukkan jumlah nilai yang ingin di-input: ";
    cin >> jumlahData;

    // Perulangan untuk menerima input nilai dari pengguna
    for (int i = 1; i <= jumlahData; i++) {
        cout << "Masukkan nilai ke-" << i << ": ";
        cin >> nilai;

        // 1. Alokasi nilai ke node baru
        Address P = alokasi(nilai);

        // 2. Masukkan node baru ke posisi paling depan (Insert First)
        insertFirst(L, P);
    }

    cout << "\n-------------------------------------------" << endl;
    // Tampilkan hasil akhir linked list
    printList(L);

    return 0;
}
