#include <iostream>
using namespace std;

// 1. Deklarasi Struktur Data Node
struct Node {
    int nilai;
    Node* next;
};

typedef Node* Address;

struct List {
    Address First;
};

// 2. Fungsi Alokasi Memori (Membuat Node Baru)
Address alokasi(int nilaiInput) {
    Address P = new Node;
    P->nilai = nilaiInput;
    P->next = NULL;
    return P;
}

// 3. Prosedur Insert After
void insertAfter(Address Prec, Address P) {
    if (Prec != NULL) {
        P->next = Prec->next;
        Prec->next = P;
    }
}

// Prosedur pembantu untuk mencari node berdasarkan nilainya
Address cariNode(List L, int nilaiCari) {
    Address P = L.First;
    while (P != NULL) {
        if (P->nilai == nilaiCari) {
            return P;
        }
        P = P->next;
    }
    return NULL;
}

// 4. Prosedur Cetak Seluruh Nilai di List
void printList(List L) {
    Address P = L.First;
    if (P == NULL) {
        cout << "List masih kosong!" << endl;
        return;
    }

    cout << "Urutan Nilai dalam List: ";
    while (P != NULL) {
        cout << "[" << P->nilai << "] -> ";
        P = P->next;
    }
    cout << "NULL" << endl;
}

// 5. Program Utama (Driver)
int main() {
    List L;
    L.First = NULL; // Inisialisasi list kosong

    // Menyiapkan data awal secara manual ([10] -> [20] -> NULL)
    L.First = alokasi(10);
    L.First->next = alokasi(20);

    cout << "=== PROGRAM INSERT AFTER ===" << endl;
    cout << "Isi List Saat Ini:" << endl;
    printList(L);

    int nilaiAcuan, nilaiBaru;
    cout << "\nDisisipkan setelah nilai : ";
    cin >> nilaiAcuan;
    cout << "Masukkan nilai baru      : ";
    cin >> nilaiBaru;

    // 1. Cari node acuan (Prec)
    Address Prec = cariNode(L, nilaiAcuan);

    if (Prec != NULL) {
        // 2. Alokasi nilai baru ke node P
        Address P = alokasi(nilaiBaru);

        // 3. Masukkan node P setelah node Prec (Insert After)
        insertAfter(Prec, P);
        cout << "\nBerhasil disisipkan!" << endl;
    } else {
        cout << "\nNilai acuan tidak ditemukan di dalam list!" << endl;
    }

    cout << "\n-------------------------------------------" << endl;
    // Tampilkan hasil akhir linked list
    printList(L);

    return 0;
}
