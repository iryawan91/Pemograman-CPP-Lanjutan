#include "Singlylist.h" // Memanggil file header agar terhubung dengan deklarasi struct dan fungsi

// 1. Prosedur Inisialisasi List
// Mengatur penunjuk First pada List L agar bernilai Nil (NULL), menandakan list awal masih kosong.
void createList(List &L) {
    L.First = Nil;
}

// 2. Fungsi Alokasi Memori (Membuat Elemen Baru)
// Memesan tempat di memori dinamis untuk struktur ElmList baru.
// Jika pemesanan berhasil (P != Nil), isi bagian info dengan nilai x dan atur next menunjuk ke Nil.
address alokasi(infotype x) {
    address P = new ElmList;
    if (P != Nil) {
        P->info = x;
        P->next = Nil;
    }
    return P; // Mengembalikan alamat memori elemen baru yang sudah dibuat
}

// 3. Prosedur Dealokasi Memori (Menghapus Elemen)
// Membebaskan/mengembalikan memori dinamis yang digunakan oleh elemen P ke sistem, lalu mengeset P ke Nil.
void dealokasi(address &P) {
    delete P;
    P = Nil;
}

// 4. Prosedur Print Info (Penelusuran/Traversing)
// Menelusuri seluruh elemen dari First hingga Nil, lalu mencetak nilai (info) tiap elemen yang dipisahkan spasi.
void printInfo(List L) {
    address P = L.First; // Pointer bantuan P dimulai dari elemen pertama (First)
    while (P != Nil) {   // Perulangan berjalan selama P belum sampai ke ujung list (Nil)
        cout << P->info << " "; // Cetak isi nilai dari elemen saat ini
        P = P->next;            // Pindah pointer P ke elemen berikutnya
    }
    cout << endl; // Cetak baris baru setelah semua elemen selesai ditampilkan
}

// 5. Prosedur Insert First (Menyisipkan Elemen di Depan)
// Menyisipkan elemen baru P ke posisi paling depan pada List L.
void insertFirst(List &L, address P) {
    if (P != Nil) {          // Memastikan elemen P yang akan dimasukkan valid (tidak kosong)
        P->next = L.First;  // Hubungkan pointer next dari P ke elemen yang tadinya berada paling depan
        L.First = P;        // Pindahkan penunjuk First agar menunjuk ke elemen baru P
    }
}
