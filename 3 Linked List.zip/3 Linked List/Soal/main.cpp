#include <iostream>     // Memanggil library standar C++ untuk fungsi input/output (seperti cout)
#include "Singlylist.h" // Memanggil file header ADT Singly Linked List agar struktur & fungsinya dapat digunakan

using namespace std; // Menggunakan namespace std agar tidak perlu menuliskan std:: pada cout

int main()
{
    // 1. Deklarasi Variabel
    List L;                            // Deklarasi variabel L dengan tipe data List
    address P1, P2, P3, P4, P5 = Nil;  // Deklarasi 5 buah pointer penunjuk (address) dan diinisialisasi awal dengan Nil (NULL)

    // 2. Inisialisasi List Kosong
    createList(L); // Memanggil prosedur untuk mengeset L.First = Nil (menandakan list awal masih kosong)

    // 3. Proses Alokasi Data dan Penyisipan ke List (Insert First)
    
    // Alokasi memori untuk nilai 2 ke pointer P1, lalu sisipkan ke posisi paling depan list L
    P1 = alokasi(2);
    insertFirst(L, P1); // Isi List saat ini: [2] -> Nil

    // Alokasi memori untuk nilai 0 ke pointer P2, lalu sisipkan ke posisi paling depan list L
    P2 = alokasi(0);
    insertFirst(L, P2); // Isi List saat ini: [0] -> [2] -> Nil

    // Alokasi memori untuk nilai 8 ke pointer P3, lalu sisipkan ke posisi paling depan list L
    P3 = alokasi(8);
    insertFirst(L, P3); // Isi List saat ini: [8] -> [0] -> [2] -> Nil

    // Alokasi memori untuk nilai 12 ke pointer P4, lalu sisipkan ke posisi paling depan list L
    P4 = alokasi(12);
    insertFirst(L, P4); // Isi List saat ini: [12] -> [8] -> [0] -> [2] -> Nil

    // Alokasi memori untuk nilai 9 ke pointer P5, lalu sisipkan ke posisi paling depan list L
    P5 = alokasi(9);
    insertFirst(L, P5); // Isi List saat ini: [9] -> [12] -> [8] -> [0] -> [2] -> Nil

    // 4. Menampilkan Hasil Akhir Linked List
    printInfo(L); // Menelusuri dan mencetak isi elemen list ke layar. Output: 9 12 8 0 2

    return 0; // Mengembalikan nilai 0, menandakan program selesai dieksekusi dengan sukses
}
