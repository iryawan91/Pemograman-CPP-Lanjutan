#ifndef SINGLYLIST_H_INCLUDED // Include Guard: Mencegah deklarasi ganda jika file header di-include beberapa kali
#define SINGLYLIST_H_INCLUDED

#include <iostream> // Library standar C++ untuk operasi input/output (cout, cin, dll)
using namespace std; // Menggunakan namespace standar agar tidak perlu menulis std:: sebelum cout/cin

// 1. Konstanta / Makro
#define Nil NULL // Mengganti kata penunjuk kosong 'NULL' menjadi 'Nil' sesuai notasi algoritmik ADT

// 2. Pendefinisian Tipe Data (Type Definition)
typedef int infotype;           // Menjadikan 'infotype' sebagai alias untuk tipe data integer (nilai yang disimpan)
typedef struct ElmList* address; // Menjadikan 'address' sebagai alias untuk pointer yang menunjuk ke struktur ElmList

// 3. Struktur Data Elemen List (Node / Simpul)
struct ElmList {
    infotype info; // Tempat menyimpan nilai atau data utama dari elemen
    address next;  // Pointer/penunjuk yang menyimpan alamat memori elemen berikutnya
};

// 4. Struktur Data Utama Linked List
struct List {
    address First; // Pointer penanda yang menunjuk ke elemen pertama (paling depan) dalam list
};

// 5. Deklarasi Protokol / Header Fungsi & Prosedur Primitif (ADT Operations)

// Prosedur untuk menginisialisasi list baru agar menjadi list kosong (First = Nil)
void createList(List &L);

// Fungsi untuk mengalokasikan memori dinamis bagi elemen baru dengan isi data 'x'
address alokasi(infotype x);

// Prosedur untuk mengembalikan/menghapus memori dari elemen 'P' yang tidak dipakai lagi
void dealokasi(address &P);

// Prosedur untuk menelusuri (traversing) dan menampilkan seluruh isi data di dalam list
void printInfo(List L);

// Prosedur untuk menyisipkan elemen baru 'P' ke posisi paling depan (paling awal) dari list 'L'
void insertFirst(List &L, address P);

#endif // SINGLYLIST_H_INCLUDED // Penutup Include Guard
