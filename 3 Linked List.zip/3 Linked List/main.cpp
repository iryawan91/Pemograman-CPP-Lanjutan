#include <iostream>
#include "Singlylist.h"

using namespace std;

int main() {
    List L;
    CreateList(L);

    // Alokasi data dan masukan ke list
    address P1 = alokasi(10);
    insertFirst(L, P1);

    address P2 = alokasi(20);
    insertFirst(L, P2);

    address P3 = alokasi(30);
    insertFirst(L, P3);

    // Tampilkan isi list
    printInfo(L); // Output: [30] -> [20] -> [10] -> NULL

    return 0;
}
