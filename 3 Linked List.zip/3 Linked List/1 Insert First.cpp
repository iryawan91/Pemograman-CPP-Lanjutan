#include <iostream>
using namespace std;

// 1. Deklarasi Struktur Data Node (Simpul)
struct Simpul {
    int nilai;
    Simpul* selanjutnya; // Menggantikan pointer 'next'
};

typedef Simpul* Alamat; // Menggantikan typedef 'Address'

struct Senarai { // Menggantikan 'List'
    Alamat Awal; // Menggantikan 'First'
};

// 2. Fungsi Alokasi Memori (Membuat Simpul Baru)
Alamat alokasi(int nilaiBaru) {
    Alamat P = new Simpul;
    P->nilai = nilaiBaru;
    P->selanjutnya = NULL;
    return P;
}

// 3. Prosedur Sisip Awal (Insert First)
void sisipAwal(Senarai &S, Alamat P) {
    P->selanjutnya = S.Awal;
    S.Awal = P;
}

// 4. Prosedur Cetak Isi Senarai
void cetakSenarai(Senarai S) {
    Alamat P = S.Awal;
    while (P != NULL) {
        cout << "[" << P->nilai << "] -> ";
        P = P->selanjutnya;
    }
    cout << "NULL" << endl;
}

// 5. Program Utama
int main() {
    Senarai S;
    S.Awal = NULL; // Inisialisasi awal senarai kosong

    // Skenario: Menyiapkan Senarai yang SUDAH ADA isinya ([85] -> [75] -> NULL)
    Alamat simpul1 = alokasi(75);
    sisipAwal(S, simpul1);

    Alamat simpul2 = alokasi(85);
    sisipAwal(S, simpul2);

    cout << "Isi Senarai Sebelum Ditambah:" << endl;
    cetakSenarai(S); // Output: [85] -> [75] -> NULL

    // ----------------------------------------------------
    // PROSES MENAMBAHKAN NILAI BARU KE SENARAI YANG SUDAH ADA
    // ----------------------------------------------------
    int nilaiMasukan;
    cout << "\nMasukkan nilai baru yang ingin ditambahkan: ";
    cin >> nilaiMasukan;

    // 1. Alokasi memori untuk nilai baru
    Alamat simpulBaru = alokasi(nilaiMasukan);

    // 2. Sisipkan ke posisi paling awal
    sisipAwal(S, simpulBaru);

    cout << "\nIsi Senarai Setelah Ditambah Nilai Baru:" << endl;
    cetakSenarai(S);

    return 0;
}
